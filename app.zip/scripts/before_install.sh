#!/bin/bash
mkdir -R /var/www/html
touch /var/www/html/teste.txt