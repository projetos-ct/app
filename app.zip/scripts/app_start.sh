#!/bin/bash
systemctl start nginx.service
systemctl enable nginx.service